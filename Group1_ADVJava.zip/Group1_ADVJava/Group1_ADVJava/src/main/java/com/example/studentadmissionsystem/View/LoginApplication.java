package com.example.studentadmissionsystem.View;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    
    public void start(Stage primaryStage) {
        // Create UI components
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("Login");
        Button signupButton = new Button("Sign Up");
        Label errorMessageLabel = new Label();
        errorMessageLabel.setStyle("-fx-text-fill: red;");
        errorMessageLabel.setWrapText(true);

        // Apply style classes to buttons
        loginButton.getStyleClass().add("login-button");
        signupButton.getStyleClass().add("signup-button");

        // Create layout
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        gridPane.add(usernameLabel, 0, 0);
        gridPane.add(usernameField, 1, 0);
        gridPane.add(passwordLabel, 0, 1);
        gridPane.add(passwordField, 1, 1);
        gridPane.add(errorMessageLabel, 1, 2, 2, 1);

        HBox hBox = new HBox(10);
        hBox.setAlignment(Pos.BOTTOM_RIGHT);
        hBox.getChildren().addAll(loginButton, signupButton);
        gridPane.add(hBox, 1, 3);

        // Handle login button click
        loginButton.setOnAction(event -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            if (username.isEmpty() || password.isEmpty()) {
                errorMessageLabel.setText("Username and password cannot be empty.");
            } else {
                errorMessageLabel.setText("");
                // Perform login logic here (simulate success)
                System.out.println("Username: " + username);
                System.out.println("Password: " + password);
                // Simulate successful login, you can redirect to another scene or action here
                clearFields(usernameField, passwordField);
            }
        });

        // Handle signup button click
        signupButton.setOnAction(event -> {
            System.out.println("Redirecting to Sign Up page...");
            primaryStage.hide();
            SignupApplication signupApp = new SignupApplication();
            Stage signupStage = new Stage();
            signupApp.start(signupStage);

        });

        // Load the logo image
        ImageView logoImageView = new ImageView();
        try {
            Image logoImage = new Image(getClass().getResource("/college_logo.png").toExternalForm());
            logoImageView.setImage(logoImage);
            logoImageView.setFitHeight(100);
            logoImageView.setPreserveRatio(true);
        } catch (NullPointerException e) {
            System.out.println("Logo image not found");
        }

        // Create the root layout
        VBox root = new VBox(10);
        root.setAlignment(Pos.TOP_CENTER);
        root.getChildren().addAll(logoImageView, gridPane);
        root.setPadding(new Insets(10, 10, 10, 10));

        Scene scene = new Scene(root, 380, 350); // Increased height to accommodate error message
        try {
            scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());
        } catch (NullPointerException e) {
            System.out.println("CSS file not found");
        }

        primaryStage.setTitle("Login Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Helper method to clear text fields
    private void clearFields(TextField usernameField, PasswordField passwordField) {
        usernameField.clear();
        passwordField.clear();
    }
}
