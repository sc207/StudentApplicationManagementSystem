package com.example.studentadmissionsystem.View;

import com.example.studentadmissionsystem.Controller.DBConnect;
import com.example.studentadmissionsystem.Controller.StudentDAO;
import com.example.studentadmissionsystem.Model.Student;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SignupApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Create UI components
        Label fullNameLabel = new Label("Full Name:");
        TextField fullNameField = new TextField();
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        Label confirmPasswordLabel = new Label("Confirm Password:");
        PasswordField confirmPasswordField = new PasswordField();
        Label dobLabel = new Label("Date of Birth:");
        DatePicker dobPicker = new DatePicker();
        Label genderLabel = new Label("Gender:");
        ComboBox<String> genderComboBox = new ComboBox<>();
        ObservableList<String> gender = FXCollections.observableArrayList(
                "Male", "Female", "Other"
        );
        genderComboBox.setItems(gender);
        genderComboBox.setPromptText("Select Gender");

        Label phoneNumberLabel = new Label("Phone Number:");
        TextField phoneNumberField = new TextField();
        Label citizenshipLabel = new Label("Citizenship:");

        // Citizenship ComboBox
        ComboBox<String> citizenshipComboBox = new ComboBox<>();
        ObservableList<String> citizenship = FXCollections.observableArrayList(
                "United States", "Canada", "United Kingdom", "Australia", "Germany", "France", "Japan", "India",
                "China", "South Korea", "Brazil", "Mexico", "Russia", "South Africa", "Other"
        );
        citizenshipComboBox.setItems(citizenship);
        citizenshipComboBox.setPromptText("Select Citizenship");
        citizenshipComboBox.getStyleClass().add("combo-box");

        CheckBox termsCheckBox = new CheckBox("I agree to the Terms and Conditions");
        Button signupButton = new Button("Sign Up");

        // Apply style classes to buttons and fields
        signupButton.getStyleClass().add("signup-button");

        // Create "Already Have An Account?" link
        Hyperlink loginLink = new Hyperlink("Already Have An Account?");
        loginLink.setOnAction(event -> {
            // Close the current SignupApplication window
            primaryStage.hide();
            // Launch LoginApplication in a new window
            LoginApplication loginApp = new LoginApplication();
            Stage loginStage = new Stage();
            loginApp.start(loginStage);
        });

        // Create layout
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        // Adding UI components in the specified order
        gridPane.add(fullNameLabel, 0, 0);
        gridPane.add(fullNameField, 1, 0);
        gridPane.add(emailLabel, 0, 1);
        gridPane.add(emailField, 1, 1);
        gridPane.add(passwordLabel, 0, 2);
        gridPane.add(passwordField, 1, 2);
        gridPane.add(confirmPasswordLabel, 0, 3);
        gridPane.add(confirmPasswordField, 1, 3);
        gridPane.add(dobLabel, 0, 4);
        gridPane.add(dobPicker, 1, 4);
        gridPane.add(genderLabel, 0, 5);
        gridPane.add(genderComboBox, 1, 5);
        gridPane.add(phoneNumberLabel, 0, 7);
        gridPane.add(phoneNumberField, 1, 7);
        gridPane.add(citizenshipLabel, 0, 8);
        gridPane.add(citizenshipComboBox, 1, 8);
        gridPane.add(termsCheckBox, 1, 9);

        HBox hBox = new HBox(10);
        hBox.setAlignment(Pos.BOTTOM_RIGHT);
        hBox.getChildren().add(signupButton);
        gridPane.add(hBox, 1, 10);

        // Load the logo image
        ImageView logoImageView = new ImageView();
        try {
            Image logoImage = new Image(getClass().getResource("/college_logo.png").toExternalForm());
            logoImageView.setImage(logoImage);
            logoImageView.setFitHeight(100);
            logoImageView.setPreserveRatio(true);
        } catch (NullPointerException e) {
            System.out.println("Logo image not found");
        }

        // Create the root layout
        VBox root = new VBox(10);
        root.setAlignment(Pos.TOP_CENTER);
        root.getChildren().addAll(logoImageView, gridPane, loginLink); // Add loginLink to root
        root.setPadding(new Insets(10, 10, 10, 10));

        Scene scene = new Scene(root, 450, 750); // Increased height to accommodate all fields
        try {
            scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());
        } catch (NullPointerException e) {
            System.out.println("CSS file not found");
        }

        // Validation logic for signup button click
        signupButton.setOnAction(event -> {
            boolean isValid = true;
            StringBuilder errorMessage = new StringBuilder();

            // Validate email
            String email = emailField.getText();
            if (email.isEmpty() || !isValidEmail(email)) {
                isValid = false;
                errorMessage.append("Valid email is required.\n");
            }

            // Validate password
            String password = passwordField.getText();
            if (password.isEmpty()) {
                isValid = false;
                errorMessage.append("Password is required.\n");
            }

            // Validate confirm password
            String confirmPassword = confirmPasswordField.getText();
            if (!password.equals(confirmPassword)) {
                isValid = false;
                errorMessage.append("Passwords do not match.\n");
            }

            // Validate full name
            if (fullNameField.getText().isEmpty()) {
                isValid = false;
                errorMessage.append("Full name is required.\n");
            }

            // Validate date of birth
            if (dobPicker.getValue() == null) {
                isValid = false;
                errorMessage.append("Date of Birth is required.\n");
            }

            // Validate phone number
            if (phoneNumberField.getText().isEmpty()) {
                isValid = false;
                errorMessage.append("Phone number is required.\n");
            }

            // Validate citizenship
            if (citizenshipComboBox.getSelectionModel().isEmpty()) {
                isValid = false;
                errorMessage.append("Citizenship is required.\n");
            }

            // Validate terms and conditions
            if (!termsCheckBox.isSelected()) {
                isValid = false;
                errorMessage.append("You must agree to the Terms and Conditions.\n");
            }

            // Display error messages if any validation fails
            if (isValid) {
                // Save student data to the database
                DBConnect dbConnect = new DBConnect();
                try (Connection connection = dbConnect.getConnection()) {
                    StudentDAO studentDAO = new StudentDAO(connection);
                    Student student = new Student(
                            0, // ID will be auto-generated
                            fullNameField.getText(),
                            emailField.getText(),
                            passwordField.getText(),
                            phoneNumberField.getText(),
                            dobPicker.getValue() != null ? dobPicker.getValue().toString() : null,
                            genderComboBox.getValue(),
                            citizenshipComboBox.getValue(),
                            "Pending", // Assuming default status is "Pending"
                            null, // DocumentName is initially null
                            false // UploadedDocuments initially false
                    );
                    studentDAO.insertStudent(student);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Signup successful!");
                    alert.showAndWait();

                    // Close the current SignupApplication window
                    primaryStage.hide();

                    // Launch LoginApplication in a new window
                    LoginApplication loginApp = new LoginApplication();
                    Stage loginStage = new Stage();
                    loginApp.start(loginStage);
                } catch (SQLException e) {
                    e.printStackTrace();
                    Alert alert = new Alert(Alert.AlertType.ERROR, "An error occurred during signup.");
                    alert.showAndWait();
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, errorMessage.toString());
                alert.showAndWait();
            }
        });

        primaryStage.setTitle("Signup Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Helper method to clear text fields
    private void clearFields(TextField fullNameField, TextField emailField,
                             PasswordField passwordField, PasswordField confirmPasswordField, DatePicker dobPicker,
                             ComboBox<String> genderComboBox, TextField phoneNumberField) {
        fullNameField.clear();
        emailField.clear();
        passwordField.clear();
        confirmPasswordField.clear();
        dobPicker.setValue(null);
        genderComboBox.getSelectionModel().clearSelection();
        phoneNumberField.clear();
    }

    // Helper method to validate email format
    private boolean isValidEmail(String email) {
        // Simple email validation, can be improved based on requirements
        return email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");
    }

    // Helper method to show alert dialog
    private void showAlert(Alert.AlertType alertType, String title, String headerText, String contentText) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.showAndWait();
    }

//    // Method to authenticate user
//    public boolean authenticateUser(String username, String password) throws SQLException {
//        String query = "SELECT COUNT(*) FROM students WHERE email = ? AND password = ?";
//        try (PreparedStatement stmt = connection.prepareStatement(query)) {
//            stmt.setString(1, username);
//            stmt.setString(2, password);
//            ResultSet rs = stmt.executeQuery();
//            if (rs.next()) {
//                return rs.getInt(1) > 0; // Returns true if there is at least one matching record
//            }
//        }
//        return false;
//    }
}
