package com.example.studentadmissionsystem.View;

import com.example.studentadmissionsystem.Controller.DBConnect;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class main {

        public static void main(String[] args) throws SQLException {
            ResultSet rS = null;
            try{
                DBConnect db= new DBConnect();
                Connection cn =db.getConnection();
                Statement st =(Statement) cn.createStatement();


                //String QueryStr = "delete from students where id=12";
                //st.executeUpdate(QueryStr);
                //System.out.println("record deleted!");
                //String QueryNewStd = "insert into students values(5, 'Raman', 'IT', 66.9)";
                // st.executeUpdate(QueryNewStd);
                // System.out.println("Updated");

                rS = st.executeQuery("Select * from admin");

            }
            catch (Exception e){
                System.out.println(e);
                e.printStackTrace();
            }


        }
    }

