package com.example.studentadmissionsystem.View;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SignupApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Create UI components
        Label firstNameLabel = new Label("First Name:");
        TextField firstNameField = new TextField();
        Label lastNameLabel = new Label("Last Name:");
        TextField lastNameField = new TextField();
        Label dobLabel = new Label("Date of Birth:");
        DatePicker dobPicker = new DatePicker();
        Label genderLabel = new Label("Gender:");
        ComboBox<String> genderComboBox = new ComboBox<>();
        genderComboBox.getItems().addAll("Male", "Female", "Other");
        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();
        Label phoneNumberLabel = new Label("Phone Number:");
        TextField phoneNumberField = new TextField();
        Label citizenshipLabel = new Label("Citizenship:");
        ComboBox<String> citizenshipComboBox = new ComboBox<>();
        citizenshipComboBox.getItems().addAll(
                "United States", "Canada", "United Kingdom", "Australia", "Germany", "France", "Japan", "India",
                "China", "South Korea", "Brazil", "Mexico", "Russia", "South Africa", "Other"
        );
        Button signupButton = new Button("Sign Up");
        Label errorMessageLabel = new Label();
        errorMessageLabel.setStyle("-fx-text-fill: red;");
        errorMessageLabel.setWrapText(true);

        // Apply style classes to buttons and fields
        signupButton.getStyleClass().add("signup-button");

        // Create "Already Have An Account?" link
        Hyperlink loginLink = new Hyperlink("Already Have An Account?");
        loginLink.setOnAction(event -> {
            // Close the current SignupApplication window
            primaryStage.hide();
            // Launch LoginApplication in a new window
            LoginApplication loginApp = new LoginApplication();
            Stage loginStage = new Stage();
            loginApp.start(loginStage);
        });

        // Create layout
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        gridPane.add(firstNameLabel, 0, 0);
        gridPane.add(firstNameField, 1, 0);
        gridPane.add(lastNameLabel, 0, 1);
        gridPane.add(lastNameField, 1, 1);
        gridPane.add(dobLabel, 0, 2);
        gridPane.add(dobPicker, 1, 2);
        gridPane.add(genderLabel, 0, 3);
        gridPane.add(genderComboBox, 1, 3);
        gridPane.add(emailLabel, 0, 4);
        gridPane.add(emailField, 1, 4);
        gridPane.add(phoneNumberLabel, 0, 5);
        gridPane.add(phoneNumberField, 1, 5);
        gridPane.add(citizenshipLabel, 0, 6);
        gridPane.add(citizenshipComboBox, 1, 6);
        gridPane.add(errorMessageLabel, 0, 7, 2, 1);

        HBox hBox = new HBox(10);
        hBox.setAlignment(Pos.BOTTOM_RIGHT);
        hBox.getChildren().add(signupButton);
        gridPane.add(hBox, 1, 8);

        // Load the logo image
        ImageView logoImageView = new ImageView();
        try {
            Image logoImage = new Image(getClass().getResource("/college_logo.png").toExternalForm());
            logoImageView.setImage(logoImage);
            logoImageView.setFitHeight(100);
            logoImageView.setPreserveRatio(true);
        } catch (NullPointerException e) {
            System.out.println("Logo image not found");
        }

        // Create the root layout
        VBox root = new VBox(10);
        root.setAlignment(Pos.TOP_CENTER);
        root.getChildren().addAll(logoImageView, gridPane, loginLink); // Add loginLink to root
        root.setPadding(new Insets(10, 10, 10, 10));

        Scene scene = new Scene(root, 450, 700); // Increased height to accommodate login link
        try {
            scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());
        } catch (NullPointerException e) {
            System.out.println("CSS file not found");
        }

        // Validation logic for signup button click
        signupButton.setOnAction(event -> {
            boolean isValid = true;
            StringBuilder errorMessage = new StringBuilder();

            // Validate first name
            if (firstNameField.getText().isEmpty()) {
                isValid = false;
                errorMessage.append("First name is required.\n");
            }

            // Validate last name
            if (lastNameField.getText().isEmpty()) {
                isValid = false;
                errorMessage.append("Last name is required.\n");
            }

            // Validate date of birth
            if (dobPicker.getValue() == null) {
                isValid = false;
                errorMessage.append("Date of Birth is required.\n");
            }

            // Validate email
            String email = emailField.getText();
            if (email.isEmpty() || !isValidEmail(email)) {
                isValid = false;
                errorMessage.append("Valid email is required.\n");
            }

            // Validate phone number
            if (phoneNumberField.getText().isEmpty()) {
                isValid = false;
                errorMessage.append("Phone number is required.\n");
            }

            // Validate citizenship
            if (citizenshipComboBox.getSelectionModel().isEmpty()) {
                isValid = false;
                errorMessage.append("Citizenship is required.\n");
            }

            // Display error messages if any validation fails
            if (!isValid) {
                errorMessageLabel.setText(errorMessage.toString());
            } else {
                // If all validations pass, clear error message and proceed with signup logic
                errorMessageLabel.setText("");
                // Perform signup logic here
                System.out.println("Signup successful!");
                // Clear fields after successful signup
                clearFields(firstNameField, lastNameField, dobPicker, genderComboBox, emailField, phoneNumberField);
            }
        });

        primaryStage.setTitle("Signup Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Helper method to clear text fields
    private void clearFields(TextField firstNameField, TextField lastNameField, DatePicker dobPicker,
                             ComboBox<String> genderComboBox, TextField emailField, TextField phoneNumberField) {
        firstNameField.clear();
        lastNameField.clear();
        dobPicker.setValue(null);
        genderComboBox.getSelectionModel().clearSelection();
        emailField.clear();
        phoneNumberField.clear();
    }

    // Helper method to validate email format
    private boolean isValidEmail(String email) {
        // Simple email validation, can be improved based on requirements
        return email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}");
    }
}
