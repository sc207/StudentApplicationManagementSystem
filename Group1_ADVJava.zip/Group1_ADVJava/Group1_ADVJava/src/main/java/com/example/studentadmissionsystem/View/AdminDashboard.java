package com.example.studentadmissionsystem.View;

import com.example.studentadmissionsystem.Model.Registrar;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class AdminDashboard extends Application {

    private TableView<Registrar> registrarTable;
    private List<Registrar> registrars;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Administrator Dashboard");

        // Initialize the list of registrars
        registrars = new ArrayList<>();
        registrars.add(new Registrar("1", "Alice Brown", "alice.brown@example.com", "123-456-7890", "Admissions", "123 Main St"));
        registrars.add(new Registrar("2", "Bob White", "bob.white@example.com", "987-654-3210", "Admissions", "456 Elm St"));

        // Create the table view for registrars
        registrarTable = new TableView<>();
        registrarTable.setPrefWidth(800);
        registrarTable.setItems(FXCollections.observableArrayList(registrars));

        // Define columns
        TableColumn<Registrar, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(data -> data.getValue().idProperty());
        TableColumn<Registrar, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(data -> data.getValue().nameProperty());
        TableColumn<Registrar, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(data -> data.getValue().emailProperty());
        TableColumn<Registrar, String> phoneNumberColumn = new TableColumn<>("Phone Number");
        phoneNumberColumn.setCellValueFactory(data -> data.getValue().phoneNumberProperty());
        TableColumn<Registrar, String> departmentColumn = new TableColumn<>("Department");
        departmentColumn.setCellValueFactory(data -> data.getValue().departmentProperty());
        TableColumn<Registrar, String> addressColumn = new TableColumn<>("Address");
        addressColumn.setCellValueFactory(data -> data.getValue().addressProperty());

        registrarTable.getColumns().addAll(idColumn, nameColumn, emailColumn, phoneNumberColumn, departmentColumn, addressColumn);

        // Create buttons
        Button addButton = new Button("Add Registrar");
        addButton.getStyleClass().add("dashboard-button");

        Button updateButton = new Button("Update Registrar");
        updateButton.getStyleClass().add("dashboard-button");

        Button deleteButton = new Button("Delete Registrar");
        deleteButton.getStyleClass().add("dashboard-button");

        Button generateReportButton = new Button("Generate Report");
        generateReportButton.getStyleClass().add("dashboard-button");

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("logout-button");

        // Set button actions
        addButton.setOnAction(e -> addRegistrar());
        updateButton.setOnAction(e -> updateRegistrar());
        deleteButton.setOnAction(e -> deleteRegistrar());
        generateReportButton.setOnAction(e -> generateReport());
        logoutButton.setOnAction(event -> {
            System.out.println("Redirecting to Login page...");
            primaryStage.hide();
            LoginApplication loginApp = new LoginApplication();
            Stage loginStage = new Stage();
            loginApp.start(loginStage);

        });

        // Layout setup
        VBox buttonBox = new VBox(10, addButton, updateButton, deleteButton, generateReportButton, logoutButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20));

        HBox mainContent = new HBox(20, buttonBox, registrarTable);
        mainContent.setPadding(new Insets(20));
        mainContent.setAlignment(Pos.CENTER);

        // College logo
        Image logo = new Image(getClass().getResourceAsStream("/college_logo.png"));
        ImageView logoView = new ImageView(logo);
        logoView.setFitHeight(100);
        logoView.setPreserveRatio(true);

        Label welcomeLabel = new Label("Administrator Dashboard");
        welcomeLabel.getStyleClass().add("welcome-label");

        HBox header = new HBox(10, logoView, welcomeLabel);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(10));
        header.getStyleClass().add("header");

        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(mainContent);
        root.getStyleClass().add("root");

        Scene scene = new Scene(root, 1000, 600);
        scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void addRegistrar() {
        Stage stage = new Stage();
        stage.setTitle("Add Registrar");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.getStyleClass().add("grid-pane");

        TextField idField = new TextField();
        idField.setPromptText("ID");
        idField.getStyleClass().add("text-field");

        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        nameField.getStyleClass().add("text-field");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.getStyleClass().add("text-field");

        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");
        phoneNumberField.getStyleClass().add("text-field");

        TextField courseField = new TextField();
        courseField.setPromptText("Course");
        courseField.getStyleClass().add("text-field");

        TextField addressField = new TextField();
        addressField.setPromptText("Address");
        addressField.getStyleClass().add("text-field");

        Button submitButton = new Button("Submit");
        submitButton.getStyleClass().add("dashboard-button");
        submitButton.setOnAction(e -> {
            String id = idField.getText();
            String name = nameField.getText();
            String email = emailField.getText();
            String phoneNumber = phoneNumberField.getText();
            String department = courseField.getText();
            String address = addressField.getText();

            if (!id.isEmpty() && !name.isEmpty() && !email.isEmpty() && !phoneNumber.isEmpty() && !department.isEmpty() && !address.isEmpty()) {
                registrars.add(new Registrar(id, name, email, phoneNumber, department, address));
                stage.close();
            } else {
                showAlert("Please fill in all fields.");
            }
        });

        gridPane.add(new Label("ID:"), 0, 0);
        gridPane.add(idField, 1, 0);
        gridPane.add(new Label("Name:"), 0, 1);
        gridPane.add(nameField, 1, 1);
        gridPane.add(new Label("Email:"), 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(new Label("Phone Number:"), 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(new Label("Department:"), 0, 4);
        gridPane.add(courseField, 1, 4);
        gridPane.add(new Label("Address:"), 0, 5);
        gridPane.add(addressField, 1, 5);
        gridPane.add(submitButton, 1, 6);

        Scene scene = new Scene(gridPane, 300, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void updateRegistrar() {
        Registrar selectedRegistrar = registrarTable.getSelectionModel().getSelectedItem();
        if (selectedRegistrar == null) {
            showAlert("Please select a registrar to update.");
            return;
        }

        Stage stage = new Stage();
        stage.setTitle("Update Registrar");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.getStyleClass().add("grid-pane");

        TextField idField = new TextField(selectedRegistrar.getId());
        idField.setEditable(false);
        idField.getStyleClass().add("text-field");

        TextField nameField = new TextField(selectedRegistrar.getName());
        nameField.getStyleClass().add("text-field");

        TextField emailField = new TextField(selectedRegistrar.getEmail());
        emailField.getStyleClass().add("text-field");

        TextField phoneNumberField = new TextField(selectedRegistrar.getPhoneNumber());
        phoneNumberField.getStyleClass().add("text-field");

        TextField departmentField = new TextField(selectedRegistrar.getDepartment());
        departmentField.getStyleClass().add("text-field");

        TextField addressField = new TextField(selectedRegistrar.getAddress());
        addressField.getStyleClass().add("text-field");

        Button submitButton = new Button("Submit");
        submitButton.getStyleClass().add("dashboard-button");
        submitButton.setOnAction(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String phoneNumber = phoneNumberField.getText();
            String department = departmentField.getText();
            String address = addressField.getText();

            if (!name.isEmpty() && !email.isEmpty() && !phoneNumber.isEmpty() && !department.isEmpty() && !address.isEmpty()) {
                selectedRegistrar.setName(name);
                selectedRegistrar.setEmail(email);
                selectedRegistrar.setPhoneNumber(phoneNumber);
                selectedRegistrar.setDepartment(department);
                selectedRegistrar.setAddress(address);
                registrarTable.refresh();
                stage.close();
            } else {
                showAlert("Please fill in all fields.");
            }
        });

        gridPane.add(new Label("ID:"), 0, 0);
        gridPane.add(idField, 1, 0);
        gridPane.add(new Label("Name:"), 0, 1);
        gridPane.add(nameField, 1, 1);
        gridPane.add(new Label("Email:"), 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(new Label("Phone Number:"), 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(new Label("Department:"), 0, 4);
        gridPane.add(departmentField, 1, 4);
        gridPane.add(new Label("Address:"), 0, 5);
        gridPane.add(addressField, 1, 5);
        gridPane.add(submitButton, 1, 6);

        Scene scene = new Scene(gridPane, 300, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void deleteRegistrar() {
        Registrar selectedRegistrar = registrarTable.getSelectionModel().getSelectedItem();
        if (selectedRegistrar != null) {
            registrars.remove(selectedRegistrar);
        } else {
            showAlert("Please select a registrar to delete.");
        }
    }

    private void generateReport() {
        StringBuilder report = new StringBuilder();
        report.append("Registrar Report\n");
        report.append("================\n");
        for (Registrar registrar : registrars) {
            report.append("ID: ").append(registrar.getId()).append(", Name: ").append(registrar.getName())
                    .append(", Email: ").append(registrar.getEmail()).append(", Phone Number: ").append(registrar.getPhoneNumber())
                    .append(", Department: ").append(registrar.getDepartment()).append(", Address: ").append(registrar.getAddress()).append("\n");
        }
        showAlert(report.toString());
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
