package com.example.studentadmissionsystem.View;

import com.example.studentadmissionsystem.Controller.DBConnect;
import com.example.studentadmissionsystem.Controller.StudentDAO;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.SQLException;

public class LoginApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Create UI components
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("Login");
        Button signupButton = new Button("Sign Up");
        Label errorMessageLabel = new Label();
        errorMessageLabel.setStyle("-fx-text-fill: red;");
        errorMessageLabel.setWrapText(true);

        // Apply style classes to buttons
        loginButton.getStyleClass().add("login-button");
        signupButton.getStyleClass().add("signup-button");

        // Create layout
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        gridPane.add(usernameLabel, 0, 0);
        gridPane.add(usernameField, 1, 0);
        gridPane.add(passwordLabel, 0, 1);
        gridPane.add(passwordField, 1, 1);
        gridPane.add(errorMessageLabel, 1, 2, 2, 1);

        HBox hBox = new HBox(10);
        hBox.setAlignment(Pos.BOTTOM_RIGHT);
        hBox.getChildren().addAll(loginButton, signupButton);
        gridPane.add(hBox, 1, 3);

        // Handle login button click
        loginButton.setOnAction(event -> handleLogin(usernameField, passwordField, errorMessageLabel, primaryStage));

        // Handle signup button click
        signupButton.setOnAction(event -> handleSignup(primaryStage));

        // Load the logo image
        ImageView logoImageView = new ImageView();
        try {
            Image logoImage = new Image(getClass().getResource("/college_logo.png").toExternalForm());
            logoImageView.setImage(logoImage);
            logoImageView.setFitHeight(100);
            logoImageView.setPreserveRatio(true);
        } catch (NullPointerException e) {
            System.out.println("Logo image not found");
        }

        // Create the root layout
        VBox root = new VBox(10);
        root.setAlignment(Pos.TOP_CENTER);
        root.getChildren().addAll(logoImageView, gridPane);
        root.setPadding(new Insets(10, 10, 10, 10));

        Scene scene = new Scene(root, 380, 350); // Increased height to accommodate error message
        try {
            scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());
        } catch (NullPointerException e) {
            System.out.println("CSS file not found");
        }

        primaryStage.setTitle("Login Page");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void handleLogin(TextField usernameField, PasswordField passwordField, Label errorMessageLabel, Stage primaryStage) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            errorMessageLabel.setText("Username and password cannot be empty.");
        } else {
            errorMessageLabel.setText("");
            DBConnect dbConnect = new DBConnect();
            try (Connection connection = dbConnect.getConnection()) {
                StudentDAO studentDAO = new StudentDAO(connection);
                boolean isAuthenticated = studentDAO.authenticateUser(username, password);

                System.out.println("Authentication result: " + isAuthenticated);

                if (isAuthenticated) {
                    if (username.equals("admin@humber.ca") && password.equals("admin1234")) {
                        clearFields(usernameField, passwordField);
                        primaryStage.hide();
                        AdminDashboard adminDashboard = new AdminDashboard();
                        Stage adminStage = new Stage();
                        adminDashboard.start(adminStage);
                    } else if (username.contains("admissions") || username.contains("finance") ||
                            username.contains("it") || username.contains("marketing") ||
                            username.contains("humanresources")) {

                        clearFields(usernameField, passwordField);
                        primaryStage.hide();

                        // Pass the username and password to the RegistrarDashboard
                        RegistrarDashboard registrarDashboard = new RegistrarDashboard(username, password);
                        Stage registrarStage = new Stage();
                        registrarDashboard.start(registrarStage);
                    } else {
                        clearFields(usernameField, passwordField);
                        primaryStage.hide();
                        StudentDashboard studentDashboard = new StudentDashboard(username, password);
                        Stage dashboardStage = new Stage();
                        studentDashboard.start(dashboardStage);
                    }
                } else {
                    errorMessageLabel.setText("Invalid username or password.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                errorMessageLabel.setText("An error occurred during login.");
                System.err.println("SQL Exception: " + e.getMessage());
            }
        }
    }

    private void handleSignup(Stage primaryStage) {
        System.out.println("Redirecting to Sign Up page...");
        primaryStage.hide();
        SignupApplication signupApp = new SignupApplication();
        Stage signupStage = new Stage();
        signupApp.start(signupStage);
    }

    // Helper method to clear text fields
    private void clearFields(TextField usernameField, PasswordField passwordField) {
        usernameField.clear();
        passwordField.clear();
    }

}
