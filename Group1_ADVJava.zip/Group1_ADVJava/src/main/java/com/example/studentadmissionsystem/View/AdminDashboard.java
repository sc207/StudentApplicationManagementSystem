
package com.example.studentadmissionsystem.View;
import com.example.studentadmissionsystem.Controller.CSVGenerator;
import com.example.studentadmissionsystem.Controller.DBConnect;
import com.example.studentadmissionsystem.Model.Registrar;
import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.example.studentadmissionsystem.Controller.CSVGenerator; // Update this path based on your package structure
public class AdminDashboard extends Application {
    private TableView<Registrar> registrarTable;
    private List<Registrar> registrars;
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Administrator Dashboard");
        // Initialize the list of registrars from the database
        registrars = loadRegistrarsFromDatabase();
        // Create the table view for registrars
        registrarTable = new TableView<>();
        registrarTable.setPrefWidth(800);
        registrarTable.setItems(FXCollections.observableArrayList(registrars));
        // Define columns
        TableColumn<Registrar, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getId()));
        TableColumn<Registrar, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getName()));
        TableColumn<Registrar, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getEmail()));
        TableColumn<Registrar, String> phoneNumberColumn = new TableColumn<>("Phone Number");
        phoneNumberColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getPhoneNumber()));
        TableColumn<Registrar, String> departmentColumn = new TableColumn<>("Department");
        departmentColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getDepartment()));
        TableColumn<Registrar, String> addressColumn = new TableColumn<>("Address");
        addressColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getAddress()));
        TableColumn<Registrar, String> passwordColumn = new TableColumn<>("Password");
        passwordColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getPassword()));
        // Add columns to the table
        registrarTable.getColumns().addAll(idColumn, nameColumn, emailColumn, phoneNumberColumn, departmentColumn, addressColumn, passwordColumn);
        // Create buttons
        Button addButton = new Button("Add Registrar");
        addButton.getStyleClass().add("dashboard-button");
        Button updateButton = new Button("Update Registrar");
        updateButton.getStyleClass().add("dashboard-button");
        Button deleteButton = new Button("Delete Registrar");
        deleteButton.getStyleClass().add("dashboard-button");
        Button generateReportButton = new Button("Generate Report");
        generateReportButton.getStyleClass().add("dashboard-button");
        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("logout-button");
        // Set button actions
        addButton.setOnAction(e -> addRegistrar());
        updateButton.setOnAction(e -> updateRegistrar());
        deleteButton.setOnAction(e -> deleteRegistrar());
        generateReportButton.setOnAction(e -> generateReport());
        logoutButton.setOnAction(event -> {
            System.out.println("Redirecting to Login page...");
            primaryStage.hide();
            LoginApplication loginApp = new LoginApplication();
            Stage loginStage = new Stage();
            loginApp.start(loginStage);
        });
        // Layout setup
        VBox buttonBox = new VBox(10, addButton, updateButton, deleteButton, generateReportButton, logoutButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20));
        HBox mainContent = new HBox(20, buttonBox, registrarTable);
        mainContent.setPadding(new Insets(20));
        mainContent.setAlignment(Pos.CENTER);
        // College logo
        Image logo = new Image(getClass().getResourceAsStream("/college_logo.png"));
        ImageView logoView = new ImageView(logo);
        logoView.setFitHeight(100);
        logoView.setPreserveRatio(true);
        Label welcomeLabel = new Label("Administrator Dashboard");
        welcomeLabel.getStyleClass().add("welcome-label");
        HBox header = new HBox(10, logoView, welcomeLabel);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(10));
        header.getStyleClass().add("header");
        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(mainContent);
        root.getStyleClass().add("root");
        Scene scene = new Scene(root, 1000, 600);
        scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private List<Registrar> loadRegistrarsFromDatabase() {
        List<Registrar> registrarList = new ArrayList<>();
        String query = "SELECT * FROM registrar";
        try (Connection connection = DBConnect.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phoneNumber = rs.getString("phone");
                String department = rs.getString("department");
                String address = rs.getString("address");
                String password = rs.getString("password");
                Registrar registrar = new Registrar(id, name, email, phoneNumber, department, address, password);
                registrarList.add(registrar);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return registrarList;
    }
    private void addRegistrar() {
        Stage stage = new Stage();
        stage.setTitle("Add Registrar");
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.getStyleClass().add("grid-pane");
        TextField idField = new TextField();
        idField.setPromptText("ID");
        idField.getStyleClass().add("text-field");
        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        nameField.getStyleClass().add("text-field");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.getStyleClass().add("text-field");
        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");
        phoneNumberField.getStyleClass().add("text-field");
        ComboBox<String> departmentComboBox = new ComboBox<>();
        ObservableList<String> departments = FXCollections.observableArrayList(
                "Admissions", "Finance", "IT", "Marketing", "Human Resources"
        );
        departmentComboBox.setItems(departments);
        departmentComboBox.setPromptText("Select Department");
        departmentComboBox.getStyleClass().add("combo-box");
        TextField addressField = new TextField();
        addressField.setPromptText("Address");
        addressField.getStyleClass().add("text-field");
        TextField passwordField = new TextField("Registrar@101");
        passwordField.setEditable(false);
        passwordField.setVisible(false);
        Button submitButton = new Button("Submit");
        submitButton.getStyleClass().add("dashboard-button");
        submitButton.setOnAction(e -> {
            String id = idField.getText();
            String name = nameField.getText();
            String email = emailField.getText();
            String phoneNumber = phoneNumberField.getText();
            String department = departmentComboBox.getValue();
            String address = addressField.getText();
            if (!id.isEmpty() && !name.isEmpty() && !email.isEmpty() && !phoneNumber.isEmpty() && department != null && !address.isEmpty()) {
                if (isDepartmentAvailable(department)) {
                    // Add registrar to the list and database
                    addRegistrarToDatabase(Integer.parseInt(id), name, email, phoneNumber, department, address, "Registrar@101");
                    registrars.add(new Registrar(Integer.parseInt(id), name, email, phoneNumber, department, address, "Registrar@101"));
                    registrarTable.setItems(FXCollections.observableArrayList(registrars));
                    stage.close();
                } else {
                    showAlert("Department already has a registrar.");
                }
            } else {
                showAlert("Please fill in all fields.");
            }
        });
        gridPane.add(new Label("ID:"), 0, 0);
        gridPane.add(idField, 1, 0);
        gridPane.add(new Label("Name:"), 0, 1);
        gridPane.add(nameField, 1, 1);
        gridPane.add(new Label("Email:"), 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(new Label("Phone Number:"), 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(new Label("Department:"), 0, 4);
        gridPane.add(departmentComboBox, 1, 4);
        gridPane.add(new Label("Address:"), 0, 5);
        gridPane.add(addressField, 1, 5);
        gridPane.add(submitButton, 1, 6);
        Scene scene = new Scene(gridPane, 400, 300);
        scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
    private boolean isDepartmentAvailable(String department) {
        for (Registrar registrar : registrars) {
            if (registrar.getDepartment().equals(department)) {
                return false;
            }
        }
        return true;
    }
    private void addRegistrarToDatabase(int id, String name, String email, String phoneNumber, String department, String address, String password) {
        String query = "INSERT INTO registrar (id, name, email, phone, department, address, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DBConnect.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, id);
            pstmt.setString(2, name);
            pstmt.setString(3, email);
            pstmt.setString(4, phoneNumber);
            pstmt.setString(5, department);
            pstmt.setString(6, address);
            pstmt.setString(7, password);
            int rowsAffected = pstmt.executeUpdate();
            System.out.println("Rows affected: " + rowsAffected);  // Debugging output
            if (rowsAffected > 0) {
                System.out.println("Registrar added successfully!");
            } else {
                System.out.println("Failed to add registrar.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("SQL Exception: " + e.getMessage());
        }
    }
    private void updateRegistrar() {
        Registrar selectedRegistrar = registrarTable.getSelectionModel().getSelectedItem();
        if (selectedRegistrar != null) {
            Stage stage = new Stage();
            stage.setTitle("Update Registrar");
            GridPane gridPane = new GridPane();
            gridPane.setPadding(new Insets(10));
            gridPane.setHgap(10);
            gridPane.setVgap(10);
            gridPane.setAlignment(Pos.CENTER);
            gridPane.getStyleClass().add("grid-pane");
            TextField idField = new TextField(String.valueOf(selectedRegistrar.getId()));
            idField.setEditable(false);
            idField.getStyleClass().add("text-field");
            TextField nameField = new TextField(selectedRegistrar.getName());
            nameField.getStyleClass().add("text-field");
            TextField emailField = new TextField(selectedRegistrar.getEmail());
            emailField.getStyleClass().add("text-field");
            TextField phoneNumberField = new TextField(selectedRegistrar.getPhoneNumber());
            phoneNumberField.getStyleClass().add("text-field");
            ComboBox<String> departmentComboBox = new ComboBox<>();
            ObservableList<String> departments = FXCollections.observableArrayList(
                    "Admissions", "Finance", "IT", "Marketing", "Human Resources"
            );
            departmentComboBox.setItems(departments);
            departmentComboBox.setValue(selectedRegistrar.getDepartment());
            departmentComboBox.getStyleClass().add("combo-box");
            TextField addressField = new TextField(selectedRegistrar.getAddress());
            addressField.getStyleClass().add("text-field");
            TextField passwordField = new TextField(selectedRegistrar.getPassword());
            passwordField.setEditable(false);
            passwordField.setVisible(false);
            Button submitButton = new Button("Submit");
            submitButton.getStyleClass().add("dashboard-button");
            submitButton.setOnAction(e -> {
                String name = nameField.getText();
                String email = emailField.getText();
                String phoneNumber = phoneNumberField.getText();
                String department = departmentComboBox.getValue();
                String address = addressField.getText();
                if (!name.isEmpty() && !email.isEmpty() && !phoneNumber.isEmpty() && department != null && !address.isEmpty()) {
                    if (isDepartmentAvailableOrSame(department, selectedRegistrar.getId())) {
                        // Update the selected registrar in the list and database
                        updateRegistrarInDatabase(selectedRegistrar.getId(), name, email, phoneNumber, department, address, passwordField.getText());
                        selectedRegistrar.setName(name);
                        selectedRegistrar.setEmail(email);
                        selectedRegistrar.setPhoneNumber(phoneNumber);
                        selectedRegistrar.setDepartment(department);
                        selectedRegistrar.setAddress(address);
                        registrarTable.refresh();
                        stage.close();
                    } else {
                        showAlert("Department already has a registrar.");
                    }
                } else {
                    showAlert("Please fill in all fields.");
                }
            });
            gridPane.add(new Label("ID:"), 0, 0);
            gridPane.add(idField, 1, 0);
            gridPane.add(new Label("Name:"), 0, 1);
            gridPane.add(nameField, 1, 1);
            gridPane.add(new Label("Email:"), 0, 2);
            gridPane.add(emailField, 1, 2);
            gridPane.add(new Label("Phone Number:"), 0, 3);
            gridPane.add(phoneNumberField, 1, 3);
            gridPane.add(new Label("Department:"), 0, 4);
            gridPane.add(departmentComboBox, 1, 4);
            gridPane.add(new Label("Address:"), 0, 5);
            gridPane.add(addressField, 1, 5);
            gridPane.add(submitButton, 1, 6);
            Scene scene = new Scene(gridPane, 400, 300);
            scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());
            stage.setScene(scene);
            stage.show();
        } else {
            showAlert("Please select a registrar to update.");
        }
    }
    private boolean isDepartmentAvailableOrSame(String department, int currentRegistrarId) {
        for (Registrar registrar : registrars) {
            if (registrar.getDepartment().equals(department) && registrar.getId() != currentRegistrarId) {
                return false;
            }
        }
        return true;
    }
    private void updateRegistrarInDatabase(int id, String name, String email, String phoneNumber, String department, String address, String password) {
        String query = "UPDATE registrar SET name = ?, email = ?, phone = ?, department = ?, address = ?, password = ? WHERE id = ?";
        try (Connection connection = DBConnect.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, department);
            pstmt.setString(5, address);
            pstmt.setString(6, password);
            pstmt.setInt(7, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private void deleteRegistrar() {
        Registrar selectedRegistrar = registrarTable.getSelectionModel().getSelectedItem();
        if (selectedRegistrar != null) {
            registrars.remove(selectedRegistrar);
            deleteRegistrarFromDatabase(selectedRegistrar.getId());
            registrarTable.setItems(FXCollections.observableArrayList(registrars));
        } else {
            showAlert("Please select a registrar to delete.");
        }
    }
    private void deleteRegistrarFromDatabase(int id) {
        String query = "DELETE FROM registrar WHERE id = ?";
        try (Connection connection = DBConnect.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private void generateReport() {
        String filePath = "registrars_report.csv";
        // Generate CSV file
        CSVGenerator.generateCSV(registrars, filePath);
        // Show CSV content
        showCSVReport(filePath);
    }
    private void showCSVReport(String filePath) {
        Stage stage = new Stage();
        stage.setTitle("CSV Report");
        TextArea textArea = new TextArea();
        textArea.setEditable(false);
        textArea.setWrapText(true);
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            textArea.setText(content.toString());
        } catch (IOException e) {
            e.printStackTrace();
            textArea.setText("Error reading CSV file.");
        }
        Scene scene = new Scene(textArea, 600, 400);
        stage.setScene(scene);
        stage.show();
    }
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
 
 