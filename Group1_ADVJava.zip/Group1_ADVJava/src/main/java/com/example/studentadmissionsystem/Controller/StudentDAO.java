package com.example.studentadmissionsystem.Controller;

import com.example.studentadmissionsystem.Model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    private Connection connection;

    public StudentDAO(Connection connection) {
        this.connection = connection;
    }

    public List<Student> fetchStudentsFromDatabase() throws SQLException {
        String query = "SELECT * FROM student";
        List<Student> students = new ArrayList<>();

        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int id = resultSet.getInt("Id");
                String name = resultSet.getString("Name");
                String email = resultSet.getString("Email");
                String phone = resultSet.getString("Phone");
                String department = resultSet.getString("Department");
                String status = resultSet.getString("Status");
                boolean uploadedDocuments = resultSet.getBoolean("UploadedDocuments"); // Fetch boolean value
                String documentName = resultSet.getString("DocumentName");

                Student student = new Student(id, name, email, phone, department, status, uploadedDocuments, documentName);
                students.add(student);
            }
        }
        return students;
    }




    public Student getStudentByUsernameAndPassword(String username, String password) throws SQLException {
        String query = "SELECT * FROM student WHERE Email = ? AND Password = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String phone = resultSet.getString("phone");
                String department=resultSet.getString("department");
                String status = resultSet.getString("status");
                return new Student(id, name, email, phone,department,status);
            }
        }
        return null;
    }

    public boolean updateStudentProfile(String name, String email, String phone, String department) throws SQLException {
        String query = "UPDATE student SET name = ?, email = ?, phone = ?, department = ? WHERE email = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phone);
            statement.setString(4, department);
            statement.setString(5, email);


            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        }
    }

    public String getDocumentPathByEmail(String email) throws SQLException {
        String documentPath = null;
        String query = "SELECT DocumentName FROM student WHERE email = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, email);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                documentPath = resultSet.getString("DocumentName");
            }
        }
        return documentPath;
    }
    public boolean saveDocument(String documentName, String email) throws SQLException {
        String query = "UPDATE student SET documentName = ? WHERE email = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, documentName);
            statement.setString(2, email);
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        }
    }

    public void deleteStudent(int studentId) throws SQLException {
        String deleteQuery = "DELETE FROM student WHERE id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
            preparedStatement.setInt(1, studentId);

            int rowsDeleted = preparedStatement.executeUpdate();

            if (rowsDeleted == 0) {
                throw new SQLException("Deleting student failed, no rows affected.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e; // Rethrow the exception to be handled by the caller
        }
    }

    public void updateStudent(Student student) throws SQLException {
        String updateQuery = "UPDATE student SET name = ?, email = ?, phone = ?, department = ?, status = ?, UploadedDocuments = ?, DocumentName = ? WHERE id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
            preparedStatement.setString(1, student.getName());
            preparedStatement.setString(2, student.getEmail());
            preparedStatement.setString(3, student.getPhone());
            preparedStatement.setString(4, student.getDepartment());
            preparedStatement.setString(5, student.getStatus());
            preparedStatement.setBoolean(6, student.isUploadedDocuments());
            preparedStatement.setString(7, student.getDocumentName());
            preparedStatement.setInt(8, student.getId());

            int rowsUpdated = preparedStatement.executeUpdate();

            if (rowsUpdated == 0) {
                throw new SQLException("Updating student failed, no rows affected.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e; // Rethrow the exception to be handled by the caller
        }
    }

    public void insertStudentByRegistrar(Student student) throws SQLException {
        String query = "INSERT INTO student ( Name, Email, Password, Phone, Department, Status, UploadedDocuments, DocumentName) " +
                "VALUES ( ?,?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {

            pstmt.setString(1, student.getName());
            pstmt.setString(2, student.getEmail());
            pstmt.setString(3, student.getEmail());
            pstmt.setString(4, student.getPhone());
            pstmt.setString(5, student.getDepartment());
            pstmt.setString(6, student.getStatus());
            pstmt.setBoolean(7, student.isUploadedDocuments());
            pstmt.setString(8, student.getDocumentName());

            pstmt.executeUpdate();
        }
    }
    public void insertStudent(Student student) throws SQLException {
        String query = "INSERT INTO student (Name, Email, Password, Phone, Department, Dob, Gender, Citizenship, Status, DocumentName, UploadedDocuments) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, student.getName());
            pstmt.setString(2, student.getEmail());
            pstmt.setString(3, student.getPassword());
            pstmt.setString(4, student.getPhone());
            pstmt.setString(5, "");
            pstmt.setString(6, student.getDob());
            pstmt.setString(7, student.getGender());
            pstmt.setString(8, student.getCitizenship());
            pstmt.setString(9, student.getStatus());
            pstmt.setString(10, student.getDocumentName());
            pstmt.setBoolean(11, student.isUploadedDocuments());

            pstmt.executeUpdate();
        }
    }
    // Method to authenticate user

    public boolean authenticateUser(String username, String password) throws SQLException {
        // Queries for different user roles
        String queryUser = "SELECT COUNT(*) FROM student WHERE email = ? AND password = ?";
        String queryAdmin = "SELECT COUNT(*) FROM admin WHERE email = ? AND password = ?";
        String queryRegistrar = "SELECT COUNT(*) FROM registrar WHERE email = ? AND password = ?";

        try (PreparedStatement pstmtUser = connection.prepareStatement(queryUser);
             PreparedStatement pstmtAdmin = connection.prepareStatement(queryAdmin);
             PreparedStatement pstmtRegistrar = connection.prepareStatement(queryRegistrar)) {

            // Check student credentials
            pstmtUser.setString(1, username);
            pstmtUser.setString(2, password);
            try (ResultSet rsUser = pstmtUser.executeQuery()) {
                if (rsUser.next() && rsUser.getInt(1) > 0) {
                    return true;
                }
            }

            // Check admin credentials
            pstmtAdmin.setString(1, username);
            pstmtAdmin.setString(2, password);
            try (ResultSet rsAdmin = pstmtAdmin.executeQuery()) {
                if (rsAdmin.next() && rsAdmin.getInt(1) > 0) {
                    return true;
                }
            }

            // Check registrar credentials
            pstmtRegistrar.setString(1, username);
            pstmtRegistrar.setString(2, password);
            try (ResultSet rsRegistrar = pstmtRegistrar.executeQuery()) {
                return rsRegistrar.next() && rsRegistrar.getInt(1) > 0;
            }
        }
    }


}
