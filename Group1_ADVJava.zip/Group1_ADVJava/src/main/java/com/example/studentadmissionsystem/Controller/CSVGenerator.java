
package com.example.studentadmissionsystem.Controller;
import com.example.studentadmissionsystem.Model.Registrar;
import com.example.studentadmissionsystem.Model.Student;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
public class CSVGenerator {

    public static void generateCSV(List<Registrar> registrars, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Write header
            writer.write("Id,Name,Email,Phone,Department,Address,Password");
            writer.newLine();
            // Write registrar data
            for (Registrar registrar : registrars) {
                writer.write(String.format("%d,%s,%s,%s,%s,%s,%s",
                        registrar.getId(),
                        registrar.getName(),
                        registrar.getEmail(),
                        registrar.getPhoneNumber(),
                        registrar.getDepartment(),
                        registrar.getAddress(),
                        registrar.getPassword()));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void generateCSV1(List<Student> students, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            // Write header
            writer.write("Id,Name,Email,Phone,Department,Address,Password");
            writer.newLine();
            // Write registrar data
            for (Student student : students) {
                writer.write(String.format("%d,%s,%s,%s,%s,%s,%s",
                        student.getId(),
                        student.getName(),
                        student.getEmail(),
                        student.getPhone(),
                        student.getDepartment(),
                        student.getStatus(),
                        student.getDocumentName()));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
 
 