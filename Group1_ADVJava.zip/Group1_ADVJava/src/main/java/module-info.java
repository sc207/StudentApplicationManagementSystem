module com.example.studentadmissionsystem {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    exports com.example.studentadmissionsystem.Model;
    opens com.example.studentadmissionsystem.Model to javafx.fxml;
    exports com.example.studentadmissionsystem.View;
    opens com.example.studentadmissionsystem.View to javafx.fxml;
    exports com.example.studentadmissionsystem.Controller;
    opens com.example.studentadmissionsystem.Controller to javafx.fxml;
}