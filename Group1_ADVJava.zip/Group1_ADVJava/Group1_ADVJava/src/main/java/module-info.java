module com.example.studentadmissionsystem {
    requires javafx.controls;
    requires javafx.fxml;



    exports com.example.studentadmissionsystem.Model;
    opens com.example.studentadmissionsystem.Model to javafx.fxml;
    exports com.example.studentadmissionsystem.View;
    opens com.example.studentadmissionsystem.View to javafx.fxml;
}