package com.example.studentadmissionsystem.View;

import com.example.studentadmissionsystem.Controller.CSVGenerator;
import com.example.studentadmissionsystem.Controller.DBConnect;
import com.example.studentadmissionsystem.Controller.StudentDAO;
import com.example.studentadmissionsystem.Model.Registrar;
import com.example.studentadmissionsystem.Model.Student;
import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


import java.io.IOException;
import java.io.InputStream;
import java.io.*;
import java.nio.file.*;
import javafx.stage.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class RegistrarDashboard extends Application {

    private TableView<Student> studentTable;
    private List<Student> students;
    private List<Student> s1;
    private Student selectedStudent;

    private String username;
    private String password;
    private File destFile;
    private StudentDAO studentDAO;

    public RegistrarDashboard(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws SQLException {
        primaryStage.setTitle("Registrar Dashboard");

        // Initialize DB and DAO
        DBConnect dbConnect = new DBConnect();
        Connection connection = dbConnect.getConnection();
        studentDAO = new StudentDAO(connection);


        // Initialize the list of students
        students = FXCollections.observableArrayList();
        //students.add(new Student(1, "John Doe", "john.doe@example.com", "123-456-7890", "Computer Science", "Accepted", "123 Main St", "Springfield", "IL", "62701", "USA", true));
        //students.add(new Student(2, "Jane Smith", "jane.smith@example.com", "987-654-3210", "Electrical Engineering", "Pending", "456 Elm St", "Springfield", "IL", "62701", "USA", false));

        // Create the table view for students
        studentTable = new TableView<>();
        studentTable.setPrefWidth(900);
        studentTable.setItems(FXCollections.observableArrayList(students));

        // Define columns
        TableColumn<Student, Object> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getId()));

        TableColumn<Student, Object> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getName()));

        TableColumn<Student, Object> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getEmail()));

        TableColumn<Student, Object> phoneNumberColumn = new TableColumn<>("Phone Number");
        phoneNumberColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getPhone()));

        TableColumn<Student, Object> departmentColumn = new TableColumn<>("Department");
        departmentColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getDepartment()));

        TableColumn<Student, Object> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getStatus()));

        TableColumn<Student, Object> documentNameColumn = new TableColumn<>("Document Name");
        documentNameColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getDocumentName()));

        TableColumn<Student, Void> downloadColumn = new TableColumn<>("Download");
        downloadColumn.setCellFactory(param -> new TableCell<>() {
            private final Button downloadButton = new Button("Download");

            {
                downloadButton.setOnAction(event -> {




                    Student student = getTableView().getItems().get(getIndex());
                    String documentName = student.getDocumentName();

                    // Implement download logic
                    downloadFile(documentName);
                });
            }

            private void downloadFile(String documentName) {
                try {
                    // Use a File object instead of URL
                    File file = new File(documentName);

                    if (file.exists()) {
                        // Open file chooser for saving the file
                        FileChooser fileChooser = new FileChooser();
                        fileChooser.setTitle("Save File");
                        fileChooser.setInitialFileName(file.getName());
                        File destinationFile = fileChooser.showSaveDialog(new Stage());

                        if (destinationFile != null) {
                            // Copy the file to the chosen path
                            try (InputStream inputStream = new FileInputStream(file);
                                 OutputStream outputStream = new FileOutputStream(destinationFile)) {
                                byte[] buffer = new byte[1024];
                                int bytesRead;
                                while ((bytesRead = inputStream.read(buffer)) != -1) {
                                    outputStream.write(buffer, 0, bytesRead);
                                }
                                System.out.println("File downloaded successfully: " + destinationFile.getAbsolutePath());
                            }
                        }
                    } else {
                        System.err.println("File not found: " + documentName);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    System.err.println("Error downloading file: " + e.getMessage());
                }
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : downloadButton);
            }
        });

        studentTable.getColumns().addAll(idColumn, nameColumn, emailColumn, phoneNumberColumn, departmentColumn, statusColumn, documentNameColumn, downloadColumn);

        // Fetch students and set data

         // Create an instance of StudentDAO
        ObservableList<Student> students = FXCollections.observableArrayList(studentDAO.fetchStudentsFromDatabase());
        studentTable.setItems(students);

        // Create buttons
        Button addButton = new Button("Add Student");
        addButton.getStyleClass().add("dashboard-button");

        Button updateButton = new Button("Update Student");
        updateButton.getStyleClass().add("dashboard-button");

        Button deleteButton = new Button("Delete Student");
        deleteButton.getStyleClass().add("dashboard-button");

        Button generateReportButton = new Button("Generate Report");
        generateReportButton.getStyleClass().add("dashboard-button");

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("logout-button");

//        Button changePasswordButton = new Button("Change Password");
//        changePasswordButton.getStyleClass().add("dashboard-button");

        // Set button actions
        addButton.setOnAction(e -> addStudent());
        updateButton.setOnAction(e -> updateStudent());
        deleteButton.setOnAction(e -> deleteStudent());

        generateReportButton.setOnAction(e -> generateReport());
        logoutButton.setOnAction(event -> {
            System.out.println("Redirecting to Login page...");
            primaryStage.hide();
            LoginApplication loginApp = new LoginApplication();
            Stage loginStage = new Stage();
            loginApp.start(loginStage);
        });
//        changePasswordButton.setOnAction(e -> changePassword());

        // Layout setup
        VBox buttonBox = new VBox(10, addButton, updateButton, deleteButton, generateReportButton, logoutButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20));

        HBox mainContent = new HBox(20, buttonBox, studentTable);
        mainContent.setPadding(new Insets(20));
        mainContent.setAlignment(Pos.CENTER);

        // College logo
        Image logo = new Image(getClass().getResourceAsStream("/college_logo.png"));
        ImageView logoView = new ImageView(logo);
        logoView.setFitHeight(100);
        logoView.setPreserveRatio(true);

        Label welcomeLabel = new Label("Registrar Dashboard");
        welcomeLabel.getStyleClass().add("welcome-label");

        HBox header = new HBox(10, logoView, welcomeLabel);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(10));
        header.getStyleClass().add("header");

        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(mainContent);
        root.getStyleClass().add("root");

        Scene scene = new Scene(root, 1000, 600);
        scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }
    private File selectedFile = null; // Class-level variable to store the selected file

    private void addStudent() {
        Stage stage = new Stage();
        stage.setTitle("Add Student");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.getStyleClass().add("grid-pane");

        TextField idField = new TextField();
        idField.setPromptText("ID");
        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");

        // Department ComboBox
        ComboBox<String> departmentComboBox = new ComboBox<>();
        ObservableList<String> departments = FXCollections.observableArrayList(
                "Admissions", "Finance", "IT", "Marketing", "Human Resources"
        );
        departmentComboBox.setItems(departments);
        departmentComboBox.setPromptText("Select Department");
        departmentComboBox.getStyleClass().add("combo-box");

        // Status ComboBox
        ComboBox<String> statusComboBox = new ComboBox<>();
        ObservableList<String> status1 = FXCollections.observableArrayList(
                "Pending", "Under Process", "Accepted", "Rejected", "Conditionally Accepted"
        );

        statusComboBox.setItems(status1);
        statusComboBox.setPromptText("Select Status");
        statusComboBox.getStyleClass().add("combo-box");

        CheckBox uploadedDocumentsCheckBox = new CheckBox("Documents Uploaded");

        // Add document selection
        TextField documentNameField = new TextField();
        documentNameField.setPromptText("Document Name");
        Button selectDocumentButton = new Button("Select Document");
        selectDocumentButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Select Document");
            selectedFile = fileChooser.showOpenDialog(stage); // Store the selected file

            if (selectedFile != null) {
                documentNameField.setText(selectedFile.getName());
            }
        });

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            String id = idField.getText();
            String name = nameField.getText();
            String email = emailField.getText();
            String phoneNumber = phoneNumberField.getText();
            String department = departmentComboBox.getValue();
            String status = statusComboBox.getValue();
            boolean uploadedDocuments = uploadedDocumentsCheckBox.isSelected();
            String documentName = documentNameField.getText();

            // Validation
            if (!id.isEmpty() && !name.isEmpty() && !email.isEmpty() && !phoneNumber.isEmpty() && !department.isEmpty() && status != null && !documentName.isEmpty()) {
                if (!email.matches("^[\\w-_.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                    showAlert(Alert.AlertType.ERROR, "Invalid Email", "Please enter a valid email address.");
                    return;
                }
                if (!phoneNumber.matches("\\d{10}")) {
                    showAlert(Alert.AlertType.ERROR, "Invalid Phone Number", "Phone number must be exactly 10 digits.");
                    return;
                }
                try {
                    Student newStudent = new Student(
                            Integer.parseInt(id),
                            name,
                            email,
                            phoneNumber,
                            department,
                            status,
                            uploadedDocuments,
                            documentName
                    );

                    studentDAO.insertStudentByRegistrar(newStudent);

                    // Handle document upload after student data is inserted
                    if (selectedFile != null) {
                        // Create the folder structure based on the student's email
                        File folder = new File("StudentDocuments" + File.separator + email);
                        if (!folder.exists()) {
                            folder.mkdirs();
                        }

                        // Define the destination file
                        File destFile = new File(folder, selectedFile.getName());

                        // Copy the file to the destination folder
                        try {
                            Files.copy(selectedFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                            boolean isSaved = studentDAO.saveDocument(destFile.getAbsolutePath(), email);
                            if (isSaved) {
                                showConfirmation("Document uploaded successfully.");
                            } else {
                                showAlert(Alert.AlertType.ERROR, "Failed to upload document.", "Document upload failed.");
                            }
                        } catch (IOException ex) {
                            showAlert(Alert.AlertType.ERROR, "File Error", "An error occurred while copying the file.");
                            ex.printStackTrace();
                        }
                    }

                    students = FXCollections.observableArrayList(studentDAO.fetchStudentsFromDatabase());
                    studentTable.setItems(FXCollections.observableArrayList(students));

                    stage.close();
                } catch (SQLException ex) {
                    showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to add student to the database.");
                    ex.printStackTrace();
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Invalid ID", "ID must be a number.");
                    ex.printStackTrace();
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "Please fill in all required fields.");
            }
        });

        gridPane.add(new Label("ID:"), 0, 0);
        gridPane.add(idField, 1, 0);
        gridPane.add(new Label("Name:"), 0, 1);
        gridPane.add(nameField, 1, 1);
        gridPane.add(new Label("Email:"), 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(new Label("Phone Number:"), 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(new Label("Department:"), 0, 4);
        gridPane.add(departmentComboBox, 1, 4);
        gridPane.add(new Label("Status:"), 0, 5);
        gridPane.add(statusComboBox, 1, 5);
        gridPane.add(uploadedDocumentsCheckBox, 0, 6, 2, 1);
        gridPane.add(new Label("Document Name:"), 0, 7);
        gridPane.add(documentNameField, 1, 7);
        gridPane.add(selectDocumentButton, 1, 8);
        gridPane.add(submitButton, 1, 9);

        Scene scene = new Scene(gridPane, 400, 500);
        stage.setScene(scene);
        stage.show();
    }



    private void showConfirmation(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private void updateStudent() {
        Student student = studentTable.getSelectionModel().getSelectedItem();
        if (student == null) {
            showAlert(Alert.AlertType.ERROR, "No Student Selected", "Please select a student to update.");
            return;
        }

        Stage stage = new Stage();
        stage.setTitle("Update Student");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.getStyleClass().add("grid-pane");

        TextField idField = new TextField();
        idField.setPromptText("ID");
        idField.setText(String.valueOf(student.getId()));
        idField.setDisable(true);
        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        nameField.setText(student.getName());
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.setText(student.getEmail());
        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");
        phoneNumberField.setText(student.getPhone());

        // Department ComboBox
        ComboBox<String> departmentComboBox = new ComboBox<>();
        ObservableList<String> departments = FXCollections.observableArrayList(
                "Admissions", "Finance", "IT", "Marketing", "Human Resources"
        );
        departmentComboBox.setItems(departments);
        departmentComboBox.setPromptText("Select Department");
        departmentComboBox.getStyleClass().add("combo-box");
        departmentComboBox.setValue(student.getDepartment());

        // Status ComboBox
        ComboBox<String> statusComboBox = new ComboBox<>();
        ObservableList<String> statusList = FXCollections.observableArrayList(
                "Pending", "Under Process", "Accepted", "Rejected", "Conditionally Accepted"
        );
        statusComboBox.setItems(statusList);
        statusComboBox.setPromptText("Select Status");
        statusComboBox.getStyleClass().add("combo-box");
        statusComboBox.setValue(student.getStatus());

        CheckBox uploadedDocumentsCheckBox = new CheckBox("Documents Uploaded");
        uploadedDocumentsCheckBox.setSelected(student.isUploadedDocuments());

        TextField documentNameField = new TextField();
        documentNameField.setPromptText("Document Name");
        documentNameField.setText(student.getDocumentName());


        Button selectDocumentButton = new Button("Select Document");
        selectDocumentButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Select Document");
            selectedFile = fileChooser.showOpenDialog(stage); // Store the selected file

            if (selectedFile != null) {
                documentNameField.setText(selectedFile.getName());
            }
        });
        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String phoneNumber = phoneNumberField.getText();
            String department = departmentComboBox.getValue();
            String status = statusComboBox.getValue();
            boolean uploadedDocuments = uploadedDocumentsCheckBox.isSelected();
            String documentName = documentNameField.getText();
            File documentFile = null; // Get the selected document file

            if (!name.isEmpty() && !email.isEmpty() && !phoneNumber.isEmpty() && !department.isEmpty() && status != null) {
                if (!email.matches("^[\\w-_.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                    showAlert(Alert.AlertType.ERROR, "Invalid Email", "Please enter a valid email address.");
                    return;
                }
                if (!phoneNumber.matches("\\d{10}")) {
                    showAlert(Alert.AlertType.ERROR, "Invalid Phone Number", "Phone number must be exactly 10 digits.");
                    return;
                }

                // Update student data
                student.setName(name);
                student.setEmail(email);
                student.setPhone(phoneNumber);
                student.setDepartment(department);
                student.setStatus(status);
                student.setUploadedDocuments(uploadedDocuments);
                student.setDocumentName(documentName);

                // Perform the update operation using StudentDAO
                try {
                    studentDAO.updateStudent(student);
                    // Handle document upload after student data is inserted
                    if (selectedFile != null) {
                        // Create the folder structure based on the student's email
                        File folder = new File("StudentDocuments" + File.separator + email);
                        if (!folder.exists()) {
                            folder.mkdirs();
                        }

                        // Define the destination file
                        File destFile = new File(folder, selectedFile.getName());

                        // Copy the file to the destination folder
                        try {
                            Files.copy(selectedFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                            boolean isSaved = studentDAO.saveDocument(destFile.getAbsolutePath(), email);
                            if (isSaved) {
                                showConfirmation("Document uploaded successfully.");
                            } else {
                                showAlert(Alert.AlertType.ERROR, "Failed to upload document.", "Document upload failed.");
                            }
                        } catch (IOException ex) {
                            showAlert(Alert.AlertType.ERROR, "File Error", "An error occurred while copying the file.");
                            ex.printStackTrace();
                        }
                    }

                    students = FXCollections.observableArrayList(studentDAO.fetchStudentsFromDatabase());
                    studentTable.setItems(FXCollections.observableArrayList(students));

                    stage.close();


                    studentTable.refresh(); // Refresh the table view
                    stage.close(); // Close the update window
                } catch (SQLException ex) {
                    showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to update student in the database.");
                    ex.printStackTrace();
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Please fill in all fields.", "Please fill in all required fields.");
            }
        });

        gridPane.add(new Label("ID:"), 0, 0);
        gridPane.add(idField, 1, 0);
        gridPane.add(new Label("Name:"), 0, 1);
        gridPane.add(nameField, 1, 1);
        gridPane.add(new Label("Email:"), 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(new Label("Phone Number:"), 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(new Label("Department:"), 0, 4);
        gridPane.add(departmentComboBox, 1, 4);
        gridPane.add(new Label("Status:"), 0, 5);
        gridPane.add(statusComboBox, 1, 5);
        gridPane.add(uploadedDocumentsCheckBox, 0, 6, 2, 1);
        gridPane.add(new Label("Document Name:"), 0, 7);
        gridPane.add(documentNameField, 1, 7);
        gridPane.add(selectDocumentButton, 1, 8);
        gridPane.add(submitButton, 1, 9);

        Scene scene = new Scene(gridPane, 400, 500);
        stage.setScene(scene);
        stage.show();
    }


    private void deleteStudent() {
        Student student = studentTable.getSelectionModel().getSelectedItem();
        if (student == null) {
            showAlert(Alert.AlertType.ERROR, "No Student Selected", "Please select a student to delete.");
            return;
        }

        try {

            studentDAO.deleteStudent(student.getId());

            // Directly remove the student from the original observable list
            students.remove(student);
            students = FXCollections.observableArrayList(studentDAO.fetchStudentsFromDatabase());
            studentTable.setItems(FXCollections.observableArrayList(students));

            showAlert(Alert.AlertType.INFORMATION, "Student Deleted", "The student record has been deleted successfully.");
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to delete student from the database.");
            e.printStackTrace();
        }
    }
    private void showCSVReport(String filePath) {
        Stage stage = new Stage();
        stage.setTitle("CSV Report");
        TextArea textArea = new TextArea();
        textArea.setEditable(false);
        textArea.setWrapText(true);
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            StringBuilder content = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
            textArea.setText(content.toString());
        } catch (IOException e) {
            e.printStackTrace();
            textArea.setText("Error reading CSV file.");
        }
        Scene scene = new Scene(textArea, 600, 400);
        stage.setScene(scene);
        stage.show();
    }
    private void generateReport() {


       // s1= FXCollections.observableArrayList(studentDAO.fetchStudentsFromDatabase());
        String filePath = "registrars_report.csv";
        // Generate CSV file
        try
        {
            ObservableList<Student> students = FXCollections.observableArrayList(studentDAO.fetchStudentsFromDatabase());
            CSVGenerator.generateCSV1(students, filePath);
            // Show CSV content
            showCSVReport(filePath);
        }catch (Exception e)
        {

        }




//        FileChooser fileChooser = new FileChooser();
//        fileChooser.setTitle("Save Report");
//        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
//        File file = fileChooser.showSaveDialog(null);
//        if (file != null) {
//            try (FileWriter writer = new FileWriter(file)) {
//                writer.append("ID,Name,Email,Phone Number,Department,Status,Document Name\n");
//                for (Student student : students) {
//                    writer.append(String.format("%d,%s,%s,%s,%s,%s,%s\n",
//                            student.getId(), student.getName(), student.getEmail(), student.getPhone(),
//                            student.getDepartment(), student.getStatus(), student.getDocumentName()));
//                }
//                writer.flush();
//                showAlert(Alert.AlertType.INFORMATION, "Report Generated", "The report has been generated successfully.");
//            } catch (IOException e) {
//                showAlert(Alert.AlertType.ERROR, "Error", "An error occurred while generating the report.");
//            }
//        }
    }

    private void changePassword() {
        Stage stage = new Stage();
        stage.setTitle("Change Password");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.getStyleClass().add("grid-pane");

        TextField emailField = new TextField();
        emailField.setPromptText("Email Address");

        PasswordField currentPasswordField = new PasswordField();
        currentPasswordField.setPromptText("Current Password");

        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("New Password");

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm New Password");

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            String email = emailField.getText();
            String currentPassword = currentPasswordField.getText();
            String newPassword = newPasswordField.getText();
            String confirmPassword = confirmPasswordField.getText();

            if (email.isEmpty() || currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Validation Error", "Please fill in all fields.");
                return;
            }
            if (!email.matches("^[\\w-_.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                showAlert(Alert.AlertType.ERROR, "Invalid Email", "Please enter a valid email address.");
                return;
            }
            if (!newPassword.equals(confirmPassword)) {
                showAlert(Alert.AlertType.ERROR, "Password Mismatch", "New passwords do not match.");
                return;
            }

            // Mockup for password change
            // In a real application, you'd need to verify the current password and update it in the database.
            showAlert(Alert.AlertType.INFORMATION, "Password Changed", "Password has been successfully changed.");

            stage.close();
        });

        gridPane.add(new Label("Email Address:"), 0, 0);
        gridPane.add(emailField, 1, 0);
        gridPane.add(new Label("Current Password:"), 0, 1);
        gridPane.add(currentPasswordField, 1, 1);
        gridPane.add(new Label("New Password:"), 0, 2);
        gridPane.add(newPasswordField, 1, 2);
        gridPane.add(new Label("Confirm New Password:"), 0, 3);
        gridPane.add(confirmPasswordField, 1, 3);
        gridPane.add(submitButton, 1, 4);

        Scene scene = new Scene(gridPane, 400, 300);
        stage.setScene(scene);
        stage.show();
    }



    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showAlert1(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
