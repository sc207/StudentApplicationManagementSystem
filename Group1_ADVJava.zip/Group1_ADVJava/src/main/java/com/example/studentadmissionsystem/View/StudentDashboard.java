package com.example.studentadmissionsystem.View;

import com.example.studentadmissionsystem.Controller.DBConnect;
import com.example.studentadmissionsystem.Controller.StudentDAO;
import com.example.studentadmissionsystem.Model.Student;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class StudentDashboard extends Application {

    private Label statusLabel;
    private TextField nameField, emailField, phoneNumberField;
    public ComboBox<String> departmentComboBox;
    private ListView<String> notificationsList;
    private StudentDAO studentDAO;
    private Button uploadDocButton, resultButton;

    private String username;
    private String password;

    private String statusLabelPrefix = "Application Status: ";
    private String status = "Pending";

    public StudentDashboard(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Student Dashboard");

        // Initialize DB and DAO
        DBConnect dbConnect = new DBConnect();
        Connection connection = dbConnect.getConnection();
        studentDAO = new StudentDAO(connection);

        // Profile information fields
        nameField = new TextField();
        emailField = new TextField();
        phoneNumberField = new TextField();

        // Department ComboBox
        departmentComboBox = new ComboBox<>();
        departmentComboBox.getItems().addAll("Admissions", "Finance", "IT", "Marketing", "Human Resources");
        departmentComboBox.setPromptText("Select Department");

        // Notifications ListView (initialize here)
        Label notificationsLabel = new Label("Notifications:");
        notificationsList = new ListView<>();

        statusLabel = new Label(statusLabelPrefix + status);
        // Fetch and fill data
        populateProfileData();

        // Profile information labels
        Label nameLabel = new Label("Name:");
        Label emailLabel = new Label("Email:");
        Label phoneNumberLabel = new Label("Phone Number:");
        Label departmentLabel = new Label("Department:");

        // Profile information layout
        GridPane profileGrid = new GridPane();
        profileGrid.setPadding(new Insets(10));
        profileGrid.setHgap(10);
        profileGrid.setVgap(10);
        profileGrid.setAlignment(Pos.CENTER);

        profileGrid.add(nameLabel, 0, 0);
        profileGrid.add(nameField, 1, 0);
        profileGrid.add(emailLabel, 0, 1);
        profileGrid.add(emailField, 1, 1);
        profileGrid.add(phoneNumberLabel, 0, 2);
        profileGrid.add(phoneNumberField, 1, 2);
        profileGrid.add(departmentLabel, 0, 3);
        profileGrid.add(departmentComboBox, 1, 3);

        Button updateProfileButton = new Button("Update Profile");
        updateProfileButton.getStyleClass().add("dashboard-button");
        updateProfileButton.setOnAction(e -> updateProfile());

        uploadDocButton = new Button("Upload Documents");
        uploadDocButton.getStyleClass().add("dashboard-button");
        uploadDocButton.setOnAction(e -> uploadDocuments(primaryStage));

        // Result Button
        resultButton = new Button("Show Result");
        resultButton.getStyleClass().add("dashboard-button");
        resultButton.setOnAction(e -> showResult());

        // Main layout
        VBox mainLayout = new VBox(20);
        mainLayout.setPadding(new Insets(10));
        mainLayout.setAlignment(Pos.CENTER);

        mainLayout.getChildren().addAll(profileGrid, updateProfileButton, statusLabel, uploadDocButton, resultButton, notificationsLabel, notificationsList);

        // College logo
        Image logo = new Image(getClass().getResourceAsStream("/college_logo.png"));
        ImageView logoView = new ImageView(logo);
        logoView.setFitHeight(100);
        logoView.setPreserveRatio(true);

        Label welcomeLabel = new Label("Student Dashboard");
        welcomeLabel.getStyleClass().add("welcome-label");

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("logout-button");
        logoutButton.setOnAction(event -> {
            primaryStage.hide();
            LoginApplication loginApp = new LoginApplication();
            Stage loginStage = new Stage();
            loginApp.start(loginStage);
        });

        HBox header = new HBox(10, logoView, welcomeLabel, logoutButton);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(10));
        header.getStyleClass().add("header");

        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(mainLayout);
        root.getStyleClass().add("root");

        Scene scene = new Scene(root, 1000, 600);
        scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void populateProfileData() {
        try {
            Student student = studentDAO.getStudentByUsernameAndPassword(username, password);
            if (student != null) {
                nameField.setText(student.getName());
                emailField.setText(student.getEmail());
                phoneNumberField.setText(student.getPhone());
                if (student.getDepartment() != null && !student.getDepartment().isEmpty()) {
                    departmentComboBox.setValue(student.getDepartment());
                }
                status = student.getStatus();
                statusLabel.setText(statusLabelPrefix + status);

                // Fetch and display the document in the notifications
                String documentPath = studentDAO.getDocumentPathByEmail(student.getEmail());
                if (documentPath != null && !documentPath.isEmpty()) {
                    addNotification("Document uploaded: " + new File(documentPath).getName());
                } else {
                    addNotification("No documents uploaded.");
                }

            } else {
                showAlert("No student found with the provided credentials.");
            }
        } catch (SQLException e) {
            showAlert("An error occurred while fetching the student data.");
            e.printStackTrace();
        }
    }

    private void updateProfile() {
        String name = nameField.getText();
        String email = emailField.getText();
        String phoneNumber = phoneNumberField.getText();
        String department = departmentComboBox.getValue();

        if (name.isEmpty() || email.isEmpty() || phoneNumber.isEmpty()) {
            showAlert("Please fill in all required fields.");
            return;
        }

        if (!isValidEmail(email)) {
            showAlert("Please enter a valid email address.");
            return;
        }

        if (!isValidPhoneNumber(phoneNumber)) {
            showAlert("Phone number must be 10 digits long.");
            return;
        }

        // If department is not selected, fetch existing department from the database
        if (department == null) {
            try {
                Student student = studentDAO.getStudentByUsernameAndPassword(username, password);
                if (student != null) {
                    department = student.getDepartment(); // Get existing department
                } else {
                    showAlert("Failed to retrieve existing department.");
                    return;
                }
            } catch (SQLException e) {
                showAlert("An error occurred while fetching the department data.");
                e.printStackTrace();
                return;
            }
        }

        try {
            boolean isUpdated = studentDAO.updateStudentProfile(name, email, phoneNumber, department);
            if (isUpdated) {
                showConfirmation("Profile updated successfully!");
            } else {
                showAlert("Failed to update profile.");
            }
        } catch (SQLException e) {
            showAlert("An error occurred while updating the profile.");
            e.printStackTrace();
        }
    }

    private void showResult() {
        String resultMessage = getResultMessage(status);
        Alert resultAlert = new Alert(Alert.AlertType.INFORMATION);
        resultAlert.setTitle("Application Result");
        resultAlert.setHeaderText(null);
        resultAlert.setContentText(resultMessage);
        resultAlert.showAndWait();
    }

    private String getResultMessage(String status) {
        switch (status) {
            case "Pending":
                return "The application has been submitted but has not yet been reviewed by the admissions committee.\n\n" +
                        "Required documents are missing or incomplete, awaiting submission by the applicant.\n\n" +
                        "The application fee has not been paid or processed.";
            case "Under Process":
                return "The application is currently being reviewed by the admissions committee.\n\n" +
                        "The applicant's academic records are being verified.\n\n" +
                        "The interview process or additional assessments are underway.\n\n" +
                        "Background checks or references are being contacted for further evaluation.";
            case "Accepted":
                return "The applicant meets all the admission criteria and has been offered a place in the program.\n\n" +
                        "The academic records and supporting documents have been verified and approved.\n\n" +
                        "The applicant has successfully passed the interview and any required assessments.";
            case "Rejected":
                return "The applicant does not meet the minimum admission requirements.\n\n" +
                        "Academic records or supporting documents did not meet the institution's standards.\n\n" +
                        "The applicant was unsuccessful in the interview or other assessments.\n\n" +
                        "The program has reached its capacity, and the applicant was not selected for admission.";
            default:
                return "Application status unknown.";
        }
    }

    private void addNotification(String notification) {
        notificationsList.getItems().add(notification);
    }

    private void uploadDocuments(Stage stage) {
        if (nameField.getText().isEmpty() || emailField.getText().isEmpty() || phoneNumberField.getText().isEmpty() || departmentComboBox.getValue() == null) {
            showAlert("Please fill in all profile fields before uploading a document.");
            return;
        }

        if (!isValidEmail(emailField.getText())) {
            showAlert("Please enter a valid email address.");
            return;
        }

        if (!isValidPhoneNumber(phoneNumberField.getText())) {
            showAlert("Phone number must be 10 digits long.");
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Upload Document");
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            try {
                // Create the folder structure based on the student's email
                String email = emailField.getText();
                File folder = new File("StudentDocuments" + File.separator + email);  // Main folder named "StudentDocuments" followed by student's email
                if (!folder.exists()) {
                    folder.mkdirs();  // Create the folder if it doesn't exist
                }

                // Save the file in the created folder
                File destFile = new File(folder, file.getName());
                file.renameTo(destFile);

                boolean isSaved = studentDAO.saveDocument(destFile.getAbsolutePath(), emailField.getText());
                if (isSaved) {
                    addNotification("Document uploaded: " + file.getName());
                    statusLabel.setText("Application Status: Under Review");
                    showConfirmation("Thank you for applying! Your application is now under review.");
                } else {
                    showAlert("Failed to upload document.");
                }
            } catch (Exception e) {
                showAlert("An error occurred while uploading the document.");
                e.printStackTrace();
            }
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showConfirmation(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean isValidEmail(String email) {
        String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";
        return Pattern.matches(emailPattern, email);
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        String phonePattern = "\\d{10}";
        return Pattern.matches(phonePattern, phoneNumber);
    }
}
