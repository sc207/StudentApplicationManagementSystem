package com.example.studentadmissionsystem.Controller;

public class RegisterDAO {
}
