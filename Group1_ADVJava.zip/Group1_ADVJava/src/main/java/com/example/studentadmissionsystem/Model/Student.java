package com.example.studentadmissionsystem.Model;

public class Student {
    private int id;
    private String name;
    private String email;
    private String password;
    private String phone;
    private String department;
    private String dob;
    private String gender;
    private String citizenship;
    private String status;
    private String documentName;
    private boolean uploadedDocuments;

    // Constructor with all fields
    public Student(int id, String name, String email, String password, String phone,
                   String dob, String gender, String citizenship,
                   String status, String documentName, boolean uploadedDocuments) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.dob = dob;
        this.gender = gender;
        this.citizenship = citizenship;
        this.status = status;
        this.documentName = documentName;
        this.uploadedDocuments = uploadedDocuments;
    }

    // Optional: remove this constructor if it's not needed
    public Student(int id, String name, String email, String phoneNumber, String department, String status, boolean uploadedDocuments, String documentName) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phoneNumber; // Use phone instead of phoneNumber
        this.department = department;
        this.status = status;
        this.documentName = documentName;
        this.uploadedDocuments = uploadedDocuments;
    }

    public Student(int id, String name, String email, String phone, String department,String status) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department=department;
        this.status=status;
    }



    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public boolean isUploadedDocuments() {
        return uploadedDocuments;
    }

    public void setUploadedDocuments(boolean uploadedDocuments) {
        this.uploadedDocuments = uploadedDocuments;
    }
}
