package com.example.studentadmissionsystem.View;

import com.example.studentadmissionsystem.Model.Student;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

public class RegistrarDashboard extends Application {

    private TableView<Student> studentTable;
    private List<Student> students;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Registrar Dashboard");

        // Initialize the list of students
        students = FXCollections.observableArrayList();
        students.add(new Student("1", "John Doe", "john.doe@example.com", "123-456-7890", "Computer Science", "Accepted"));
        students.add(new Student("2", "Jane Smith", "jane.smith@example.com", "987-654-3210", "Electrical Engineering", "Pending"));

        // Create the table view for students
        studentTable = new TableView<>();
        studentTable.setPrefWidth(800);
        studentTable.setItems(FXCollections.observableArrayList(students));

        // Define columns
        TableColumn<Student, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(data -> data.getValue().idProperty());
        TableColumn<Student, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(data -> data.getValue().nameProperty());
        TableColumn<Student, String> emailColumn = new TableColumn<>("Email");
        emailColumn.setCellValueFactory(data -> data.getValue().emailProperty());
        TableColumn<Student, String> phoneNumberColumn = new TableColumn<>("Phone Number");
        phoneNumberColumn.setCellValueFactory(data -> data.getValue().phoneNumberProperty());
        TableColumn<Student, String> departmentColumn = new TableColumn<>("Department");
        departmentColumn.setCellValueFactory(data -> data.getValue().departmentProperty());
        TableColumn<Student, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(data -> data.getValue().statusProperty());

        studentTable.getColumns().addAll(idColumn, nameColumn, emailColumn, phoneNumberColumn, departmentColumn, statusColumn);

        // Create buttons
        Button addButton = new Button("Add Student");
        addButton.getStyleClass().add("dashboard-button");

        Button updateButton = new Button("Update Student");
        updateButton.getStyleClass().add("dashboard-button");

        Button deleteButton = new Button("Delete Student");
        deleteButton.getStyleClass().add("dashboard-button");

        Button generateReportButton = new Button("Generate Report");
        generateReportButton.getStyleClass().add("dashboard-button");

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("logout-button");

        // Set button actions
        addButton.setOnAction(e -> addStudent());
        updateButton.setOnAction(e -> updateStudent());
        deleteButton.setOnAction(e -> deleteStudent());
        generateReportButton.setOnAction(e -> generateReport());
        logoutButton.setOnAction(event -> {
            System.out.println("Redirecting to Login page...");
            primaryStage.hide();
            LoginApplication loginApp = new LoginApplication();
            Stage loginStage = new Stage();
            loginApp.start(loginStage);

        });


        // Layout setup
        VBox buttonBox = new VBox(10, addButton, updateButton, deleteButton, generateReportButton, logoutButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(20));

        HBox mainContent = new HBox(20, buttonBox, studentTable);
        mainContent.setPadding(new Insets(20));
        mainContent.setAlignment(Pos.CENTER);

        // College logo
        Image logo = new Image(getClass().getResourceAsStream("/college_logo.png"));
        ImageView logoView = new ImageView(logo);
        logoView.setFitHeight(100);
        logoView.setPreserveRatio(true);

        Label welcomeLabel = new Label("Registrar Dashboard");
        welcomeLabel.getStyleClass().add("welcome-label");

        HBox header = new HBox(10, logoView, welcomeLabel);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(10));
        header.getStyleClass().add("header");

        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(mainContent);
        root.getStyleClass().add("root");

        Scene scene = new Scene(root, 1000, 600);
        scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();







    }

    private void addStudent() {
        Stage stage = new Stage();
        stage.setTitle("Add Registrar");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.getStyleClass().add("grid-pane");



        TextField idField = new TextField();
        idField.setPromptText("ID");
        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        TextField phoneNumberField = new TextField();
        phoneNumberField.setPromptText("Phone Number");
        TextField departmentField = new TextField();
        departmentField.setPromptText("Department");
        ComboBox<String> statusComboBox = new ComboBox<>();
        statusComboBox.getItems().addAll("Pending", "Under Process", "Accepted", "Rejected", "Conditionally Accepted");

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            String id = idField.getText();
            String name = nameField.getText();
            String email = emailField.getText();
            String phoneNumber = phoneNumberField.getText();
            String department = departmentField.getText();
            String status = statusComboBox.getValue();

            if (!id.isEmpty() && !name.isEmpty() && !email.isEmpty() && !phoneNumber.isEmpty() && !department.isEmpty() && status != null) {
                students.add(new Student(id, name, email, phoneNumber, department, status));
                stage.close();
            } else {
                showAlert("Please fill in all fields.");
            }
        });

        gridPane.add(new Label("ID:"), 0, 0);
        gridPane.add(idField, 1, 0);
        gridPane.add(new Label("Name:"), 0, 1);
        gridPane.add(nameField, 1, 1);
        gridPane.add(new Label("Email:"), 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(new Label("Phone Number:"), 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(new Label("Department:"), 0, 4);
        gridPane.add(departmentField, 1, 4);
        gridPane.add(new Label("Status:"), 0, 5);
        gridPane.add(statusComboBox, 1, 5);
        gridPane.add(submitButton, 1, 6);

        Scene scene = new Scene(gridPane, 300, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void updateStudent() {
        Student selectedStudent = studentTable.getSelectionModel().getSelectedItem();
        if (selectedStudent == null) {
            showAlert("Please select a student to update.");
            return;
        }

        Stage stage = new Stage();
        stage.setTitle("Update Student");

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        TextField idField = new TextField(selectedStudent.getId());
        idField.setEditable(false);
        TextField nameField = new TextField(selectedStudent.getName());
        TextField emailField = new TextField(selectedStudent.getEmail());
        TextField phoneNumberField = new TextField(selectedStudent.getPhoneNumber());
        TextField departmentField = new TextField(selectedStudent.getDepartment());
        ComboBox<String> statusComboBox = new ComboBox<>();
        statusComboBox.getItems().addAll("Pending", "Under Process", "Accepted", "Rejected", "Conditionally Accepted");
        statusComboBox.setValue(selectedStudent.getStatus());

        Button submitButton = new Button("Submit");
        submitButton.setOnAction(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String phoneNumber = phoneNumberField.getText();
            String department = departmentField.getText();
            String status = statusComboBox.getValue();

            if (!name.isEmpty() && !email.isEmpty() && !phoneNumber.isEmpty() && !department.isEmpty() && status != null) {
                selectedStudent.setName(name);
                selectedStudent.setEmail(email);
                selectedStudent.setPhoneNumber(phoneNumber);
                selectedStudent.setDepartment(department);
                selectedStudent.setStatus(status);
                studentTable.refresh();
                stage.close();
            } else {
                showAlert("Please fill in all fields.");
            }
        });

        gridPane.add(new Label("ID:"), 0, 0);
        gridPane.add(idField, 1, 0);
        gridPane.add(new Label("Name:"), 0, 1);
        gridPane.add(nameField, 1, 1);
        gridPane.add(new Label("Email:"), 0, 2);
        gridPane.add(emailField, 1, 2);
        gridPane.add(new Label("Phone Number:"), 0, 3);
        gridPane.add(phoneNumberField, 1, 3);
        gridPane.add(new Label("Department:"), 0, 4);
        gridPane.add(departmentField, 1, 4);
        gridPane.add(new Label("Status:"), 0, 5);
        gridPane.add(statusComboBox, 1, 5);
        gridPane.add(submitButton, 1, 6);

        Scene scene = new Scene(gridPane, 300, 300);
        stage.setScene(scene);
        stage.show();
    }

    private void deleteStudent() {
        Student selectedStudent = studentTable.getSelectionModel().getSelectedItem();
        if (selectedStudent != null) {
            students.remove(selectedStudent);
        } else {
            showAlert("Please select a student to delete.");
        }
    }

    private void generateReport() {
        StringBuilder report = new StringBuilder();
        report.append("Student Report\n");
        report.append("================\n");
        for (Student student : students) {
            report.append("ID: ").append(student.getId()).append(", Name: ").append(student.getName())
                    .append(", Email: ").append(student.getEmail()).append(", Phone Number: ").append(student.getPhoneNumber())
                    .append(", Department: ").append(student.getDepartment()).append(", Status: ").append(student.getStatus()).append("\n");
        }
        showAlert(report.toString());
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
