package com.example.studentadmissionsystem.View;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class StudentDashboard extends Application {

    private Label statusLabel;
    private TextField nameField, emailField, phoneNumberField, departmentField;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Student Dashboard");

        // Profile information fields
        nameField = new TextField();
        emailField = new TextField();
        phoneNumberField = new TextField();
        departmentField = new TextField();

        // Profile information labels
        Label nameLabel = new Label("Name:");
        Label emailLabel = new Label("Email:");
        Label phoneNumberLabel = new Label("Phone Number:");
        Label departmentLabel = new Label("Department:");

        // Profile information layout
        GridPane profileGrid = new GridPane();
        profileGrid.setPadding(new Insets(10));
        profileGrid.setHgap(10);
        profileGrid.setVgap(10);
        profileGrid.setAlignment(Pos.CENTER);

        profileGrid.add(nameLabel, 0, 0);
        profileGrid.add(nameField, 1, 0);
        profileGrid.add(emailLabel, 0, 1);
        profileGrid.add(emailField, 1, 1);
        profileGrid.add(phoneNumberLabel, 0, 2);
        profileGrid.add(phoneNumberField, 1, 2);
        profileGrid.add(departmentLabel, 0, 3);
        profileGrid.add(departmentField, 1, 3);

        Button updateProfileButton = new Button("Update Profile");
        updateProfileButton.getStyleClass().add("dashboard-button");

        updateProfileButton.setOnAction(e -> updateProfile());

        // Application status
        statusLabel = new Label("Application Status: Pending");

        // Document upload button
        Button uploadDocButton = new Button("Upload Documents");
        uploadDocButton.getStyleClass().add("dashboard-button");

        uploadDocButton.setOnAction(e -> uploadDocuments(primaryStage));

        // Notifications
        Label notificationsLabel = new Label("Notifications:");
        ListView<String> notificationsList = new ListView<>();
        notificationsList.getItems().addAll("Notification 1", "Notification 2", "Notification 3");

        // Main layout
        VBox mainLayout = new VBox(20);
        mainLayout.setPadding(new Insets(10));
        mainLayout.setAlignment(Pos.CENTER);

        mainLayout.getChildren().addAll(profileGrid, updateProfileButton, statusLabel, uploadDocButton, notificationsLabel, notificationsList);


        // College logo
        Image logo = new Image(getClass().getResourceAsStream("/college_logo.png"));
        ImageView logoView = new ImageView(logo);
        logoView.setFitHeight(100);
        logoView.setPreserveRatio(true);

        Label welcomeLabel = new Label("Registrar Dashboard");
        welcomeLabel.getStyleClass().add("welcome-label");

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("logout-button");
        logoutButton.setOnAction(event -> {
            System.out.println("Redirecting to Login page...");
            primaryStage.hide();
            LoginApplication loginApp = new LoginApplication();
            Stage loginStage = new Stage();
            loginApp.start(loginStage);

        });

        HBox header = new HBox(10, logoView, welcomeLabel,logoutButton);
        header.setAlignment(Pos.CENTER);
        header.setPadding(new Insets(10));
        header.getStyleClass().add("header");



        BorderPane root = new BorderPane();
        root.setTop(header);
        root.setCenter(mainLayout);
        root.getStyleClass().add("root");

        Scene scene = new Scene(root, 1000, 600);
        scene.getStylesheets().add(getClass().getResource("/Style.css").toExternalForm());

        primaryStage.setScene(scene);
        primaryStage.show();

    }

    private void updateProfile() {
        String name = nameField.getText();
        String email = emailField.getText();
        String phoneNumber = phoneNumberField.getText();
        String department = departmentField.getText();


        // For now, just printing to console
        System.out.println("Profile updated: " + name + ", " + email + ", " + phoneNumber + ", " + department);
    }

    private void uploadDocuments(Stage stage) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Upload Document");
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            // Handle the uploaded file
            System.out.println("Document uploaded: " + file.getName());
        }
    }
}
