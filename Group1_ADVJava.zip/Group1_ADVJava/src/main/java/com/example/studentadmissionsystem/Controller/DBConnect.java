package com.example.studentadmissionsystem.Controller;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBConnect {
        //declaring variables
        public String dbName;
        public String username;
        public String password;
        public int portNumber;

        //getters and setters
        public String getDbName() {
            return dbName;
        }

        public void setDbName(String dbName) {
            this.dbName = dbName;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public int getPortNumber() {
            return portNumber;
        }

        public void setPortNumber(int portNumber) {
            this.portNumber = portNumber;
        }

        public static Connection getConnection() { //here Connection is an interface

            String Username = "root";
            String Password = "admin1234";
            String ConnectionString = "jdbc:mysql://localhost:3306/studentmanagementsystem";
            Connection cn = null;   //provides method for connecting to database
            ResultSet rS = null;    //holds result of query
            Statement stm = null;   //used for executing static SQL statements

            try {
                cn= DriverManager.getConnection(ConnectionString,Username,Password);
                System.out.println("Database is Connected Successfully");
                stm = cn.createStatement(); //creates a statement object for sending SQL statements to database
            } catch (Exception e) {
                System.out.println(e);
            }
            return cn;
        }
    }


